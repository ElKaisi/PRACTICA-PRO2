var searchData=
[
  ['torneo',['Torneo',['../class_torneo.html',1,'']]]
];
