var searchData=
[
  ['main',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['mj',['mj',['../class_cjt__jugador.html#a93f85322bcdf9c6f2d7cd3fd8dc4e19c',1,'Cjt_jugador']]],
  ['modificar_5fposicion',['modificar_posicion',['../class_jugador.html#a29a8b620936c6b233af7c0afe4face06',1,'Jugador']]],
  ['modificar_5fstats',['modificar_stats',['../class_cjt__jugador.html#a7c306f49213364dd8b10f741bd740f9d',1,'Cjt_jugador::modificar_stats()'],['../class_jugador.html#afe3bffd64b1be536d2741039491433d8',1,'Jugador::modificar_stats()']]],
  ['mt',['mt',['../class_cjt__torneo.html#ace297542281791371b840d9f3c754523',1,'Cjt_torneo']]]
];
