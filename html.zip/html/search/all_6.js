var searchData=
[
  ['hacer_5femparejamientos',['hacer_emparejamientos',['../class_torneo.html#ac48cd6c73298d3a460fafe98b3bb9ee7',1,'Torneo']]],
  ['hist',['hist',['../class_torneo.html#a633d6f7034c6e5f512fa77066f5b50cf',1,'Torneo']]]
];
