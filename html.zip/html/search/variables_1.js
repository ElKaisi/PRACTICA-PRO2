var searchData=
[
  ['categoria',['categoria',['../class_torneo.html#a11e92eb8b9d4901f9b99055d7e132d0f',1,'Torneo']]],
  ['cjt_5fcat',['cjt_cat',['../class_cjt__categoria.html#aca1ca8e6a8b9150c88d679143c00fc9a',1,'Cjt_categoria']]]
];
