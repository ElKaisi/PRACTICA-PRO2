var searchData=
[
  ['finalizar_5ftorneo',['finalizar_torneo',['../class_cjt__torneo.html#a53ef8e9dc2b76c49dc6775ba7777e241',1,'Cjt_torneo::finalizar_torneo()'],['../class_torneo.html#a14091b5b818f3363226f2e102a3a12c6',1,'Torneo::finalizar_torneo()']]]
];
