var searchData=
[
  ['torneo_2ecc',['torneo.cc',['../torneo_8cc.html',1,'']]],
  ['torneo_2ehh',['torneo.hh',['../torneo_8hh.html',1,'']]]
];
