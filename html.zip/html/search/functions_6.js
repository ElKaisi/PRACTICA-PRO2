var searchData=
[
  ['hacer_5femparejamientos',['hacer_emparejamientos',['../class_torneo.html#ac48cd6c73298d3a460fafe98b3bb9ee7',1,'Torneo']]]
];
