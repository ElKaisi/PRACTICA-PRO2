var searchData=
[
  ['jugador',['Jugador',['../class_jugador.html',1,'']]]
];
