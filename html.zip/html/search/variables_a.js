var searchData=
[
  ['torneos',['torneos',['../class_jugador.html#a2c4256c69ddf76e1c4f1e48f56ed305c',1,'Jugador']]]
];
