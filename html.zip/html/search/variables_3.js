var searchData=
[
  ['juegos_5fganados',['juegos_ganados',['../class_jugador.html#a247512711054381114385e2f1fa700d4',1,'Jugador']]],
  ['juegos_5fperdidos',['juegos_perdidos',['../class_jugador.html#a1de1086b5980b69ff4a69e212e6ad387',1,'Jugador']]]
];
