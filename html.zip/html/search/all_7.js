var searchData=
[
  ['inciar_5ftorneo',['inciar_torneo',['../class_cjt__torneo.html#a5f828d976878609f28206171db707b8f',1,'Cjt_torneo']]],
  ['iniciar_5ftorneo',['iniciar_torneo',['../class_torneo.html#a43be0dc2f8a788533a9971341e833318',1,'Torneo']]]
];
