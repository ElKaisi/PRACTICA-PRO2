var searchData=
[
  ['node',['Node',['../struct_bin_tree_1_1_node.html#af45885e303875c018e89fa5c8b96bde0',1,'BinTree::Node']]],
  ['nombre',['nombre',['../class_cjt__categoria.html#a04d20c4f569b03618abf3bda34b9cda3',1,'Cjt_categoria']]],
  ['nuevo_5fjugador',['nuevo_jugador',['../class_cjt__jugador.html#a7857a0339c4938013713dfe4232155ae',1,'Cjt_jugador']]],
  ['nuevo_5ftorneo',['nuevo_torneo',['../class_cjt__torneo.html#a87171894eaa4828aa3c811f06cb7d4dd',1,'Cjt_torneo']]],
  ['num_5ftorneos',['num_torneos',['../class_cjt__torneo.html#ae5a9d9cafd828d96f5b37fd4b516f02c',1,'Cjt_torneo']]]
];
