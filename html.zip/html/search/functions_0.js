var searchData=
[
  ['anadir_5fjugador',['anadir_jugador',['../class_cjt__jugador.html#a3e36c5e6e8637ca66a910295ac0a1a91',1,'Cjt_jugador']]],
  ['anadir_5ftorneo',['anadir_torneo',['../class_cjt__torneo.html#a1586ac1bf4b5eeb3c8ae697692ac7bd8',1,'Cjt_torneo']]]
];
