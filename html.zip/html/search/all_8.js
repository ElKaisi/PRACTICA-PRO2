var searchData=
[
  ['juegos_5fganados',['juegos_ganados',['../class_jugador.html#a247512711054381114385e2f1fa700d4',1,'Jugador']]],
  ['juegos_5fperdidos',['juegos_perdidos',['../class_jugador.html#a1de1086b5980b69ff4a69e212e6ad387',1,'Jugador']]],
  ['jugador',['Jugador',['../class_jugador.html',1,'Jugador'],['../class_jugador.html#a232c46f75691af6210096e5972535d71',1,'Jugador::Jugador()']]],
  ['jugador_2ecc',['jugador.cc',['../jugador_8cc.html',1,'']]],
  ['jugador_2ehh',['jugador.hh',['../jugador_8hh.html',1,'']]]
];
