var searchData=
[
  ['desplazar',['desplazar',['../class_cjt__jugador.html#aac3396a622c2319bab5391e0e91213cf',1,'Cjt_jugador']]]
];
