var searchData=
[
  ['se_5fha_5fjugado',['se_ha_jugado',['../class_torneo.html#af66cca46dfa56c37409a9d900cadc4d7',1,'Torneo']]],
  ['string_5freader',['string_reader',['../class_torneo.html#a62a36a5c9422295b9f78afe00da50bef',1,'Torneo']]]
];
