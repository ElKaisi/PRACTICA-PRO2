var searchData=
[
  ['puntos_5fobtenidos',['puntos_obtenidos',['../class_cjt__categoria.html#a6ce99d1fa61085e4a62d562630c93bb6',1,'Cjt_categoria']]]
];
