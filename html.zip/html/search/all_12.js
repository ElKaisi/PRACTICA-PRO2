var searchData=
[
  ['value',['value',['../class_bin_tree.html#a734e785b089c87b49187ee7c58edf5f3',1,'BinTree']]],
  ['vi',['vi',['../class_torneo.html#a7c430a15253a017446aaf21771e81666',1,'Torneo']]]
];
