var searchData=
[
  ['torneo',['Torneo',['../class_torneo.html#a7bf6d35a7ec8d0e13a0bed8deb8add3e',1,'Torneo::Torneo()'],['../class_torneo.html#a6b9bb6a91223a016cef4729d7fc92d0b',1,'Torneo::Torneo(int cat, Cjt_categoria &amp;cats)']]]
];
