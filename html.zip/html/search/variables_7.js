var searchData=
[
  ['p',['p',['../class_bin_tree.html#afe3647af1dda90f6ddf1deee6560fcf1',1,'BinTree']]],
  ['partidos_5fganados',['partidos_ganados',['../class_jugador.html#a527d08a5df60746c8ec1714a5342d179',1,'Jugador']]],
  ['partidos_5fperdidos',['partidos_perdidos',['../class_jugador.html#aad69af3e0363f7aa590ecf8fdc2d1b0d',1,'Jugador']]],
  ['posicion',['posicion',['../class_jugador.html#a0c0f3be497388acec0e2c890dcd46850',1,'Jugador']]],
  ['puntos',['puntos',['../class_jugador.html#a4e264d857d5a3f1a68cbb13e4b88930f',1,'Jugador']]]
];
