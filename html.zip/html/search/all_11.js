var searchData=
[
  ['torneo',['Torneo',['../class_torneo.html',1,'Torneo'],['../class_torneo.html#a7bf6d35a7ec8d0e13a0bed8deb8add3e',1,'Torneo::Torneo()'],['../class_torneo.html#a6b9bb6a91223a016cef4729d7fc92d0b',1,'Torneo::Torneo(int cat, Cjt_categoria &amp;cats)']]],
  ['torneo_2ecc',['torneo.cc',['../torneo_8cc.html',1,'']]],
  ['torneo_2ehh',['torneo.hh',['../torneo_8hh.html',1,'']]],
  ['torneos',['torneos',['../class_jugador.html#a2c4256c69ddf76e1c4f1e48f56ed305c',1,'Jugador']]]
];
