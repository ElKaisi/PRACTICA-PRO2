var searchData=
[
  ['hist',['hist',['../class_torneo.html#a633d6f7034c6e5f512fa77066f5b50cf',1,'Torneo']]]
];
