var searchData=
[
  ['vi',['vi',['../class_torneo.html#a7c430a15253a017446aaf21771e81666',1,'Torneo']]]
];
