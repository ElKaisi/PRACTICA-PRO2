var searchData=
[
  ['ordenar_5fpor_5fpuntos',['ordenar_por_puntos',['../class_cjt__jugador.html#a593284d3eef2264c51b5eba9f01e926f',1,'Cjt_jugador']]]
];
