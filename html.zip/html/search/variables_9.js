var searchData=
[
  ['sets_5fganados',['sets_ganados',['../class_jugador.html#a160353141857719b4ebfd178ebb93d77',1,'Jugador']]],
  ['sets_5fperdidos',['sets_perdidos',['../class_jugador.html#abd96da6bc3300d334a28ab06fd208214',1,'Jugador']]]
];
