var searchData=
[
  ['quitar_5fjugador',['quitar_jugador',['../class_cjt__jugador.html#a6127d9f4519b1246c434aaaa75e90110',1,'Cjt_jugador']]],
  ['quitar_5fpuntuacion',['quitar_puntuacion',['../class_torneo.html#a940254b71a0997121b3dd1ba93697f1f',1,'Torneo']]],
  ['quitar_5ftorneo',['quitar_torneo',['../class_cjt__torneo.html#a7b8d759d3b8eeca704e3b72628597c47',1,'Cjt_torneo']]]
];
