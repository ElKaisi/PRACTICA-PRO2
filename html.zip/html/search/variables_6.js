var searchData=
[
  ['nombres_5fcategorias',['nombres_categorias',['../class_cjt__categoria.html#a96b9c554a4a25baeaadf77f12a10c7b0',1,'Cjt_categoria']]],
  ['num_5fcategoria',['num_categoria',['../class_torneo.html#ab841568e23815f1e1e9d46e30fd761ec',1,'Torneo']]]
];
